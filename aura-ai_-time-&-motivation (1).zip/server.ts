import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import webpush from 'web-push';
import cron from 'node-cron';
import admin from 'firebase-admin';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
let db: any;
try {
  const firebaseConfigPath = path.join(__dirname, 'firebase-applet-config.json');
  if (fs.existsSync(firebaseConfigPath)) {
    const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'));
    
    if (!admin.apps.length) {
      admin.initializeApp({
        credential: admin.credential.applicationDefault(),
        projectId: firebaseConfig.projectId,
      });
    }
    db = admin.firestore(firebaseConfig.firestoreDatabaseId);
  } else {
    console.error('firebase-applet-config.json not found. Firestore features will be disabled.');
  }
} catch (error) {
  console.error('Failed to initialize Firebase Admin:', error);
}

// VAPID Keys setup
let vapidKeys = {
  publicKey: process.env.VITE_VAPID_PUBLIC_KEY || '',
  privateKey: process.env.VAPID_PRIVATE_KEY || ''
};

if (!vapidKeys.publicKey || !vapidKeys.privateKey) {
  const generated = webpush.generateVAPIDKeys();
  vapidKeys = generated;
  console.log('Generated new VAPID keys. Add these to your .env:');
  console.log(`VITE_VAPID_PUBLIC_KEY=${generated.publicKey}`);
  console.log(`VAPID_PRIVATE_KEY=${generated.privateKey}`);
}

try {
  if (vapidKeys.publicKey && vapidKeys.privateKey) {
    webpush.setVapidDetails(
      'mailto:support@aura-ai.app',
      vapidKeys.publicKey,
      vapidKeys.privateKey
    );
  }
} catch (error) {
  console.error('Failed to set VAPID details:', error);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post('/api/notifications/subscribe', async (req, res) => {
    if (!db) return res.status(503).json({ error: 'Firestore not initialized' });
    const { subscription, userId } = req.body;
    try {
      await db.collection('subscriptions').doc(userId).set({
        subscription,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
      res.status(201).json({ message: 'Subscribed successfully' });
    } catch (error) {
      console.error('Subscription error:', error);
      res.status(500).json({ error: 'Failed to subscribe' });
    }
  });

  app.get('/api/notifications/vapid-public-key', (req, res) => {
    res.json({ publicKey: vapidKeys.publicKey });
  });

  // Cron job to check for upcoming tasks every minute
  cron.schedule('* * * * *', async () => {
    if (!db) return;
    console.log('Checking for upcoming tasks...');
    const now = new Date();
    const oneMinuteFromNow = new Date(now.getTime() + 60000);

    try {
      const tasksSnapshot = await db.collection('tasks')
        .where('status', '==', 'pending')
        .where('scheduledTime', '>=', now.toISOString())
        .where('scheduledTime', '<=', oneMinuteFromNow.toISOString())
        .get();

      for (const doc of tasksSnapshot.docs) {
        const task = doc.data();
        const userId = task.userId;

        const subDoc = await db.collection('subscriptions').doc(userId).get();
        if (subDoc.exists) {
          const { subscription } = subDoc.data()!;
          
          const payload = JSON.stringify({
            title: 'Aura Mission Alert',
            body: `Time to start: ${task.name}. Focus on your protocol.`,
            url: '/?screen=home'
          });

          webpush.sendNotification(subscription, payload).catch(err => {
            console.error('Push error for user', userId, err);
            if (err.statusCode === 410) {
              // Subscription expired or removed
              db.collection('subscriptions').doc(userId).delete();
            }
          });
        }
      }
    } catch (error) {
      console.error('Cron error:', error);
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
