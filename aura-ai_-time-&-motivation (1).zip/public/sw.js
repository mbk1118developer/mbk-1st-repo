self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : { title: 'Aura AI', body: 'Time for your next mission.' };
  
  const options = {
    body: data.body,
    icon: '/icon-192.png', // Fallback if icon not provided
    badge: '/badge-72.png',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    },
    actions: [
      { action: 'open', title: 'Open Aura' },
      { action: 'close', title: 'Dismiss' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow(event.notification.data.url)
    );
  }
});
