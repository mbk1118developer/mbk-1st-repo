import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X } from 'lucide-react';

interface MotivationalToastProps {
  message: string;
  onClose: () => void;
}

export const MotivationalToast: React.FC<MotivationalToastProps> = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
      className="fixed bottom-24 left-4 right-4 md:left-auto md:right-8 md:w-96 z-50"
    >
      <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-2xl border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-primary">
          <motion.div 
            initial={{ width: "100%" }}
            animate={{ width: "0%" }}
            transition={{ duration: 5, ease: "linear" }}
            className="h-full bg-white/20"
          />
        </div>
        
        <div className="flex gap-4 items-start relative z-10">
          <div className="bg-primary/20 p-2 rounded-xl">
            <Sparkles className="text-primary" size={24} />
          </div>
          <div className="flex-1 space-y-1">
            <p className="text-xs font-black uppercase tracking-widest text-primary">Aura's Recognition</p>
            <p className="text-sm font-medium leading-relaxed">{message}</p>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X size={18} />
          </button>
        </div>
        
        {/* Decorative background element */}
        <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-primary/10 rounded-full blur-2xl"></div>
      </div>
    </motion.div>
  );
};
