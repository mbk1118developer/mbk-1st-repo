import React from 'react';
import { Task, TaskStatus } from '../types';
import { CheckCircle2, Circle, Clock, Trash2, AlertCircle, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { format, parseISO, isToday } from 'date-fns';

interface TaskCardProps {
  task: Task;
  onStatusChange: (task: Task, status: TaskStatus) => void | Promise<void>;
  onDelete: (id: string) => void | Promise<void>;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, onStatusChange, onDelete }) => {
  const isCompleted = task.status === 'completed';
  const scheduledDate = task.scheduledTime ? parseISO(task.scheduledTime) : null;
  const timeStr = scheduledDate ? format(scheduledDate, 'h:mm a') : 'No time';
  const dateStr = scheduledDate && !isToday(scheduledDate) ? format(scheduledDate, 'MMM dd') : null;

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`glass-card p-5 flex items-center gap-4 group transition-all ${isCompleted ? 'bg-slate-50/50 opacity-75' : 'hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5'}`}
    >
      <button 
        onClick={() => onStatusChange(task, isCompleted ? 'pending' : 'completed')}
        className={`transition-all transform hover:scale-110 ${isCompleted ? 'text-primary' : 'text-slate-300 hover:text-primary'}`}
      >
        {isCompleted ? <CheckCircle2 size={28} strokeWidth={2.5} /> : <Circle size={28} strokeWidth={2} />}
      </button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className={`font-bold truncate text-lg ${isCompleted ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
            {task.name}
          </h3>
          {task.isAiGenerated && (
            <span className="text-[10px] font-black bg-primary/10 text-primary px-1.5 py-0.5 rounded uppercase tracking-tighter">AI</span>
          )}
        </div>
        
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1.5">
          <span className="text-xs font-bold px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md uppercase tracking-wider">
            {task.category}
          </span>
          <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
            <Clock size={14} className="text-slate-400" />
            {timeStr} {task.duration && <span className="text-slate-300 ml-1">({task.duration}m)</span>}
          </span>
          {dateStr && (
            <span className="text-xs text-primary flex items-center gap-1 font-bold">
              <Calendar size={14} />
              {dateStr}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        {!isCompleted && (
          <button 
            onClick={() => onStatusChange(task, 'skipped')}
            className="p-2 text-slate-400 hover:text-danger hover:bg-danger/5 rounded-xl transition-all"
            title="Skip Task"
          >
            <AlertCircle size={20} />
          </button>
        )}
        <button 
          onClick={() => onDelete(task.id)}
          className="p-2 text-slate-400 hover:text-danger hover:bg-danger/5 rounded-xl transition-all"
          title="Delete Task"
        >
          <Trash2 size={20} />
        </button>
      </div>
    </motion.div>
  );
}

