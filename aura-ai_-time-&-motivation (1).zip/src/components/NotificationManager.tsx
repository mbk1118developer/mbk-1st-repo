import React, { useEffect, useState } from 'react';
import { UserProfile } from '../types';
import { Bell, BellOff, Loader2, PlusCircle } from 'lucide-react';

export function NotificationManager({ profile }: { profile: UserProfile }) {
  const [status, setStatus] = useState<NotificationPermission | 'unsupported'>('default');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) {
      setStatus('unsupported');
      return;
    }
    setStatus(Notification.permission);
  }, []);

  const subscribe = async () => {
    setLoading(true);
    try {
      const permission = await Notification.requestPermission();
      setStatus(permission);

      if (permission === 'granted') {
        const registration = await navigator.serviceWorker.register('/sw.js');
        
        // Wait for service worker to be ready
        await navigator.serviceWorker.ready;

        const response = await fetch('/api/notifications/vapid-public-key');
        const { publicKey } = await response.json();

        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey)
        });

        await fetch('/api/notifications/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subscription, userId: profile.uid })
        });
      }
    } catch (error) {
      console.error('Subscription failed:', error);
    } finally {
      setLoading(false);
    }
  };

  if (status === 'unsupported') return null;
  if (status === 'granted') return null;

  return (
    <div className="glass-card p-6 bg-primary/5 border-primary/20 flex items-center justify-between gap-4">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-primary/10 rounded-2xl text-primary">
          <Bell size={24} />
        </div>
        <div className="space-y-1">
          <h4 className="font-black text-slate-900 uppercase tracking-tight">Enable Protocol Alerts</h4>
          <p className="text-xs text-slate-500 font-medium">Get reminders even when Aura is closed.</p>
        </div>
      </div>
      <button
        onClick={subscribe}
        disabled={loading}
        className="px-6 py-3 bg-primary text-white rounded-xl font-black text-sm shadow-lg shadow-primary/20 hover:opacity-90 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2"
      >
        {loading ? <Loader2 className="animate-spin" size={18} /> : <PlusCircle size={18} />}
        Activate
      </button>
    </div>
  );
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

