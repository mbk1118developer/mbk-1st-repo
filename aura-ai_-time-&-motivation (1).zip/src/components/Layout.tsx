import React from 'react';
import { Home, PlusCircle, BarChart3, LogOut, User as UserIcon } from 'lucide-react';
import { UserProfile } from '../types';
import { auth } from '../firebase';
import { motion } from 'motion/react';

interface LayoutProps {
  children: React.ReactNode;
  currentScreen: 'home' | 'add' | 'dashboard';
  onNavigate: (screen: 'home' | 'add' | 'dashboard') => void;
  profile: UserProfile | null;
}

export function Layout({ children, currentScreen, onNavigate, profile }: LayoutProps) {
  return (
    <div className="min-h-screen bg-slate-50 pb-24 md:pb-0 md:pl-64">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-12 px-2">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl">A</div>
          <span className="font-bold text-xl tracking-tight">Aura AI</span>
        </div>

        <nav className="flex-1 space-y-2">
          <NavItem 
            active={currentScreen === 'home'} 
            onClick={() => onNavigate('home')}
            icon={<Home size={20} />}
            label="Today"
          />
          <NavItem 
            active={currentScreen === 'add'} 
            onClick={() => onNavigate('add')}
            icon={<PlusCircle size={20} />}
            label="Add Tasks"
          />
          <NavItem 
            active={currentScreen === 'dashboard'} 
            onClick={() => onNavigate('dashboard')}
            icon={<BarChart3 size={20} />}
            label="Analytics"
          />
        </nav>

        <div className="mt-8 p-4 bg-slate-50 rounded-2xl border border-slate-100">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Daily Progress</span>
            <span className="text-xs font-bold text-primary">{profile?.disciplineScore}%</span>
          </div>
          <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${profile?.disciplineScore || 0}%` }}
              className="h-full bg-primary"
            />
          </div>
          <p className="mt-3 text-[10px] text-slate-500 font-medium leading-tight">
            Maintain your protocol to increase your focus score.
          </p>
        </div>

        <div className="pt-6 border-t border-slate-100 mt-auto">
          <div className="flex items-center gap-3 px-2 mb-6">
            <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-slate-500">
              <UserIcon size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 truncate">{profile?.name}</p>
              <p className="text-xs text-slate-500 truncate">Score: {profile?.disciplineScore}</p>
            </div>
          </div>
          <button 
            onClick={() => auth.signOut()}
            className="flex items-center gap-3 px-3 py-2 w-full text-slate-500 hover:text-danger transition-colors text-sm font-medium"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-slate-200 px-6 py-3 flex justify-between items-center z-50">
        <MobileNavItem 
          active={currentScreen === 'home'} 
          onClick={() => onNavigate('home')}
          icon={<Home size={24} />}
        />
        <MobileNavItem 
          active={currentScreen === 'add'} 
          onClick={() => onNavigate('add')}
          icon={<PlusCircle size={24} />}
        />
        <MobileNavItem 
          active={currentScreen === 'dashboard'} 
          onClick={() => onNavigate('dashboard')}
          icon={<BarChart3 size={24} />}
        />
        <button onClick={() => auth.signOut()} className="p-2 text-slate-400">
          <LogOut size={24} />
        </button>
      </nav>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto p-6 md:p-10">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 w-full rounded-xl font-medium transition-all ${
        active 
          ? 'bg-primary/10 text-primary' 
          : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function MobileNavItem({ active, onClick, icon }: { active: boolean, onClick: () => void, icon: React.ReactNode }) {
  return (
    <button 
      onClick={onClick}
      className={`p-3 rounded-2xl transition-all ${
        active ? 'bg-primary text-white shadow-lg shadow-primary/20 scale-110' : 'text-slate-400'
      }`}
    >
      {icon}
    </button>
  );
}
