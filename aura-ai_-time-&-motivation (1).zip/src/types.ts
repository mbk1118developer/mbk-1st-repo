/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TaskCategory = 'Study' | 'Gym/Fitness' | 'Work' | 'Sports' | 'Religious' | 'Personal';
export type TaskStatus = 'pending' | 'doing' | 'completed' | 'skipped' | 'delayed';
export type ToneMode = 'Strict' | 'Gentle' | 'Friendly';
export type PlanType = 'Daily' | 'Weekly' | 'Monthly';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  disciplineScore: number;
  consistencyScore: number;
  improvementScore: number;
  tonePreference: ToneMode;
  createdAt: string;
  lastActiveDate?: string;
}

export interface Task {
  id: string;
  userId: string;
  name: string;
  category: TaskCategory;
  scheduledTime?: string; // ISO string
  durationMinutes?: number;
  status: TaskStatus;
  responseTime?: string; // ISO string
  isAiGenerated: boolean;
  createdAt: string;
  completedAt?: string;
  delayedCount: number;
  planType?: PlanType;
  isRecurring?: boolean;
}

export interface DailySummary {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  totalTasks: number;
  completed: number;
  delayed: number;
  skipped: number;
  completionRate: number;
  aiInsight: string;
  performanceTrend: 'improving' | 'declining' | 'stable';
}

export interface AIResponse {
  tasks?: Partial<Task>[];
  motivation?: string;
  insight?: string;
}
