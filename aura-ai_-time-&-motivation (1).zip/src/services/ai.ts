import { GoogleGenAI, Type } from "@google/genai";
import { Task, TaskCategory, UserProfile, DailySummary, PlanType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const generateSchedule = async (taskNames: string[], userProfile: UserProfile, planType: PlanType): Promise<Partial<Task>[]> => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `As a senior time management AI, generate a highly realistic ${planType} schedule for these tasks: ${taskNames.join(", ")}.
    
    CRITICAL RULES FOR SCHEDULING:
    1. Durations: 
       - Gym/Fitness: 45-90 mins
       - Study: 60-120 min blocks
       - Religious (Namaz/Prayer): 10-15 mins fixed intervals
       - Work: 60-180 min blocks
       - Personal: 15-45 mins
    2. Time Slots:
       - Gym: Early morning or late afternoon
       - Study: Morning or late evening (high focus)
       - Work: Standard daytime hours
       - Religious: Spread throughout the day at traditional intervals
    3. Plan Context: This is a ${planType} plan. 
    
    Return a JSON array of tasks with 'name', 'category', 'scheduledTime' (ISO string for today), 'durationMinutes', and 'isRecurring' (boolean).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING },
            scheduledTime: { type: Type.STRING },
            durationMinutes: { type: Type.NUMBER },
            isRecurring: { type: Type.BOOLEAN }
          },
          required: ["name", "category", "scheduledTime", "durationMinutes", "isRecurring"]
        }
      }
    }
  });

  const response = await model;
  return JSON.parse(response.text || "[]");
};

export const getMotivationalMessage = async (task: Task, userProfile: UserProfile, behavior: string): Promise<string> => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate a motivational notification message for task: "${task.name}" (${task.category}).
    User behavior: ${behavior}.
    Tone: ${userProfile.tonePreference}.
    User name: ${userProfile.name}.
    Keep it short and impactful.`,
  });

  const response = await model;
  return response.text || "Time to get moving!";
};

export const getContextualMotivation = async (upcomingTasks: Task[], profile: UserProfile): Promise<string> => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are Aura, a high-performance behavioral coach. 
    The user (${profile.name}) has these upcoming tasks: ${upcomingTasks.map(t => t.name).join(', ')}.
    Current time: ${new Date().toLocaleTimeString()}.
    Discipline Score: ${profile.disciplineScore}.
    
    Provide a short, punchy, and highly motivational "Aura Protocol" message (max 20 words).
    If there are important tasks like Gym or Study, focus on the mental shift needed.
    Be direct, slightly intense, and professional.`,
  });

  const response = await model;
  return response.text || "Protocol initiated. Stay focused on the mission.";
};

export const analyzePerformance = async (tasks: Task[], userProfile: UserProfile): Promise<Partial<DailySummary>> => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze this user's task performance: ${JSON.stringify(tasks)}.
    Identify patterns, weaknesses, and provide a summary insight.
    Return a JSON object with aiInsight and performanceTrend (improving, declining, stable).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          aiInsight: { type: Type.STRING },
          performanceTrend: { type: Type.STRING }
        },
        required: ["aiInsight", "performanceTrend"]
      }
    }
  });

  const response = await model;
  return JSON.parse(response.text || "{}");
};
