import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, updateDoc, doc, deleteDoc, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Task, UserProfile, TaskStatus } from '../types';
import { TaskCard } from '../components/TaskCard';
import { MotivationalToast } from '../components/MotivationalToast';
import { NotificationManager } from '../components/NotificationManager';
import { getMotivationalMessage } from '../services/ai';
import { 
  Calendar, 
  Zap, 
  Target, 
  Brain, 
  Sparkles, 
  History as HistoryIcon,
  LayoutGrid,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isToday, isPast, parseISO, startOfDay, addDays, isBefore } from 'date-fns';

export default function Home({ profile }: { profile: UserProfile }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [aiInsight, setAiInsight] = useState<string>("Analyzing your behavioral patterns...");

  useEffect(() => {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', profile.uid),
      orderBy('scheduledTime', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const taskList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task));
      setTasks(taskList);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'tasks');
    });

    return () => unsubscribe();
  }, [profile.uid]);

  const maintenancePerformed = React.useRef(false);

  // Maintenance: Shift overdue tasks once on load
  useEffect(() => {
    if (tasks.length > 0 && !maintenancePerformed.current) {
      const maintenance = async () => {
        maintenancePerformed.current = true;
        const today = startOfDay(new Date());
        const updates: Promise<void>[] = [];

        tasks.forEach((task) => {
          if (task.scheduledTime && task.status === 'pending') {
            const taskDate = parseISO(task.scheduledTime);
            if (isBefore(taskDate, today)) {
              if (task.isRecurring) {
                const newTime = new Date();
                const oldTime = parseISO(task.scheduledTime);
                newTime.setHours(oldTime.getHours(), oldTime.getMinutes());
                
                updates.push(updateDoc(doc(db, 'tasks', task.id), {
                  scheduledTime: newTime.toISOString(),
                  delayedCount: (task.delayedCount || 0) + 1
                }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `tasks/${task.id}`)));
              } else {
                updates.push(updateDoc(doc(db, 'tasks', task.id), {
                  status: 'delayed'
                }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `tasks/${task.id}`)));
              }
            }
          }
        });

        if (updates.length > 0) {
          await Promise.all(updates);
        }
      };

      maintenance();
    }
  }, [tasks]); 

  useEffect(() => {
    const checkUpcomingTasks = async () => {
      const now = new Date();
      const upcoming = tasks.find(t => {
        if (!t.scheduledTime || t.status !== 'pending') return false;
        const taskTime = parseISO(t.scheduledTime);
        const diff = taskTime.getTime() - now.getTime();
        return diff > 0 && diff < 5 * 60 * 1000; // Next 5 minutes
      });

      if (upcoming) {
        const msg = await getMotivationalMessage(upcoming, profile, 'starting soon');
        setToastMessage(msg);
      }
    };

    const interval = setInterval(checkUpcomingTasks, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [tasks, profile]);

  const handleStatusChange = async (task: Task, newStatus: TaskStatus) => {
    const updates: any = { status: newStatus };
    if (newStatus === 'completed') {
      updates.completedAt = new Date().toISOString();
    }
    
    await updateDoc(doc(db, 'tasks', task.id), updates);
    
    if (newStatus === 'completed') {
      const msg = await getMotivationalMessage(task, profile, 'completed on time');
      setToastMessage(msg);
      
      // Update discipline score
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        disciplineScore: Math.min(100, profile.disciplineScore + 2)
      });
    }
  };

  const handleDelete = async (id: string) => {
    await deleteDoc(doc(db, 'tasks', id));
  };

  const todayTasks = tasks.filter(t => t.scheduledTime && isToday(parseISO(t.scheduledTime)));
  const pendingTasks = todayTasks.filter(t => t.status === 'pending' || t.status === 'delayed' || t.status === 'doing');
  const completedToday = todayTasks.filter(t => t.status === 'completed');
  const historyTasks = tasks.filter(t => t.scheduledTime && !isToday(parseISO(t.scheduledTime)));

  const progress = todayTasks.length > 0 
    ? Math.round((completedToday.length / todayTasks.length) * 100) 
    : 0;

  return (
    <div className="space-y-10">
      <NotificationManager profile={profile} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
      <div className="lg:col-span-2 space-y-10">
        {/* Dynamic Header */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-primary font-black uppercase tracking-widest text-xs">
              <Calendar size={14} />
              {format(new Date(), 'EEEE, MMMM do')}
            </div>
            <h1 className="text-5xl font-black text-slate-900 tracking-tight">
              Aura <span className="text-primary">Protocol</span>
            </h1>
          </div>
          
          <div className="flex items-center gap-3">
            <StatBadge label="Energy" value="85%" icon={<Zap size={14} />} color="bg-amber-500" />
            <StatBadge label="Focus" value={`${profile.disciplineScore}`} icon={<Brain size={14} />} color="bg-indigo-500" />
          </div>
        </header>

        {/* AI Insight Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 bg-slate-900 text-white relative overflow-hidden group"
        >
          <div className="relative z-10 flex gap-6 items-start">
            <div className="bg-primary/20 p-4 rounded-2xl group-hover:scale-110 transition-transform">
              <Sparkles className="text-primary" size={32} />
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-widest text-primary">Live Strategy</span>
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></div>
              </div>
              <p className="text-xl font-medium leading-relaxed italic text-slate-200">
                "{aiInsight}"
              </p>
            </div>
          </div>
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-primary/10 rounded-full blur-3xl"></div>
        </motion.div>

        {/* Task Sections */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
                {showHistory ? 'Mission History' : 'Your Mission Today'}
              </h2>
              <span className="bg-slate-100 text-slate-500 px-3 py-1 rounded-full text-xs font-black">
                {showHistory ? historyTasks.length : pendingTasks.length}
              </span>
            </div>
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 text-sm font-black text-slate-400 hover:text-primary transition-colors uppercase tracking-widest"
            >
              {showHistory ? <LayoutGrid size={18} /> : <HistoryIcon size={18} />}
              {showHistory ? 'Current' : 'History'}
            </button>
          </div>

          <div className="grid gap-4">
            <AnimatePresence mode="popLayout">
              {(showHistory ? historyTasks : pendingTasks).map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  onStatusChange={handleStatusChange}
                  onDelete={handleDelete}
                />
              ))}
            </AnimatePresence>
            
            {!showHistory && pendingTasks.length === 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20 glass-card border-dashed border-2"
              >
                <div className="bg-slate-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="text-slate-300" size={32} />
                </div>
                <p className="text-slate-500 font-bold">All protocols cleared. You are ahead of schedule.</p>
              </motion.div>
            )}
          </div>

          {!showHistory && completedToday.length > 0 && (
            <div className="space-y-4 pt-6 border-t border-slate-100">
              <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">Recently Completed</h3>
              <div className="grid gap-4 opacity-60">
                {completedToday.map((task) => (
                  <TaskCard 
                    key={task.id} 
                    task={task} 
                    onStatusChange={handleStatusChange}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Sidebar Stats */}
      <div className="space-y-8">
        <div className="glass-card p-8 space-y-8 sticky top-8">
          <div className="space-y-4">
            <h3 className="font-black text-slate-900 uppercase tracking-tight">Daily Progress</h3>
            <div className="relative h-4 bg-slate-100 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="absolute top-0 left-0 h-full bg-primary shadow-[0_0_10px_rgba(16,185,129,0.5)]"
              />
            </div>
            <div className="flex justify-between text-xs font-black uppercase tracking-widest">
              <span className="text-slate-400">Efficiency</span>
              <span className="text-primary">{progress}%</span>
            </div>
          </div>

          <div className="space-y-6 pt-6 border-t border-slate-100">
            <SummaryItem label="Missions" value={todayTasks.length} />
            <SummaryItem label="Completed" value={completedToday.length} />
            <SummaryItem label="Focus Score" value={profile.disciplineScore} />
          </div>

          <div className="p-6 bg-primary/5 rounded-3xl border border-primary/10 space-y-3">
            <p className="text-xs font-black text-primary uppercase tracking-widest">Next Strategy</p>
            <p className="text-sm text-slate-600 font-medium leading-relaxed">
              Your focus peaks at 10:00 AM. Aura suggests scheduling your 'Study' block then.
            </p>
            <button className="text-primary text-xs font-black flex items-center gap-1 hover:gap-2 transition-all uppercase tracking-widest">
              View Plan <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>

    <AnimatePresence>
        {toastMessage && (
          <MotivationalToast 
            message={toastMessage} 
            onClose={() => setToastMessage(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function StatBadge({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) {
  return (
    <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-2xl shadow-sm border border-slate-100">
      <div className={`${color} p-1 rounded-lg text-white`}>{icon}</div>
      <div className="flex flex-col">
        <span className="text-[10px] font-black text-slate-400 uppercase leading-none">{label}</span>
        <span className="text-sm font-black text-slate-900 leading-none mt-0.5">{value}</span>
      </div>
    </div>
  );
}

function SummaryItem({ label, value }: { label: string, value: string | number }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm font-bold text-slate-500">{label}</span>
      <span className="text-lg font-black text-slate-900">{value}</span>
    </div>
  );
}


