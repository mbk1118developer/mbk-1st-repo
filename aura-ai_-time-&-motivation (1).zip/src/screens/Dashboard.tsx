import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Task, UserProfile, DailySummary } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, AreaChart, Area, LineChart, Line
} from 'recharts';
import { TrendingUp, TrendingDown, Target, Zap, Brain, Award, AlertTriangle, Info, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { analyzePerformance } from '../services/ai';
import { motion } from 'motion/react';
import { format, subDays, startOfDay, parseISO } from 'date-fns';

export default function Dashboard({ profile }: { profile: UserProfile }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [insight, setInsight] = useState<Partial<DailySummary>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'tasks'),
      where('userId', '==', profile.uid),
      orderBy('createdAt', 'desc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const taskList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task));
      setTasks(taskList);
      
      if (taskList.length > 3) {
        try {
          const analysis = await analyzePerformance(taskList, profile);
          setInsight(analysis);
        } catch (error) {
          console.error("AI Analysis failed", error);
        }
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'tasks');
    });

    return () => unsubscribe();
  }, [profile.uid]);

  // Process data for trend chart (last 7 days)
  const trendData = Array.from({ length: 7 }).map((_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dateStr = format(date, 'MMM dd');
    const dayTasks = tasks.filter(t => t.createdAt && format(parseISO(t.createdAt), 'MMM dd') === dateStr);
    const completed = dayTasks.filter(t => t.status === 'completed').length;
    const rate = dayTasks.length > 0 ? (completed / dayTasks.length) * 100 : 0;
    return { name: dateStr, rate };
  });

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === 'completed').length,
    skipped: tasks.filter(t => t.status === 'skipped').length,
    delayed: tasks.filter(t => t.delayedCount > 0).length,
  };

  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

  const categoryData = [
    { name: 'Study', value: tasks.filter(t => t.category === 'Study' && t.status === 'completed').length },
    { name: 'Gym', value: tasks.filter(t => t.category === 'Gym/Fitness' && t.status === 'completed').length },
    { name: 'Work', value: tasks.filter(t => t.category === 'Work' && t.status === 'completed').length },
    { name: 'Religious', value: tasks.filter(t => t.category === 'Religious' && t.status === 'completed').length },
    { name: 'Personal', value: tasks.filter(t => t.category === 'Personal' && t.status === 'completed').length },
  ].filter(d => d.value > 0);

  const COLORS = ['#10b981', '#6366f1', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="space-y-10">
      <header className="space-y-2">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Intelligence Hub</h1>
        <p className="text-slate-500 text-lg">Aura's deep analysis of your behavioral architecture.</p>
      </header>

      {/* Score Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <ScoreCard 
          label="Discipline" 
          score={profile.disciplineScore} 
          icon={<Zap className="text-primary" />}
          trend={insight.performanceTrend === 'improving' ? 'up' : 'down'}
          description="Your ability to follow the AI strategy."
        />
        <ScoreCard 
          label="Reliability" 
          score={completionRate} 
          suffix="%"
          icon={<Target className="text-secondary" />}
          trend={completionRate > 70 ? 'up' : 'down'}
          description="Percentage of missions successfully completed."
        />
        <ScoreCard 
          label="Consistency" 
          score={profile.consistencyScore} 
          icon={<Award className="text-accent" />}
          trend="up"
          description="Streak of active days without skipping."
        />
      </div>

      {/* Main Trend Chart */}
      <div className="glass-card p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-slate-900">Performance Velocity</h3>
            <p className="text-sm text-slate-500">Tracking your completion rate over the last 7 days.</p>
          </div>
          <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${insight.performanceTrend === 'improving' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
            {insight.performanceTrend === 'improving' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {insight.performanceTrend?.toUpperCase()}
          </div>
        </div>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                cursor={{ stroke: '#10b981', strokeWidth: 2 }}
              />
              <Area type="monotone" dataKey="rate" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorRate)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insight Section */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-10 bg-slate-900 text-white relative overflow-hidden"
      >
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-10 items-center">
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center gap-4">
              <div className="bg-primary/20 p-3 rounded-2xl">
                <Brain className="text-primary" size={32} />
              </div>
              <div className="space-y-1">
                <h2 className="text-2xl font-black uppercase tracking-tighter">Aura's Strategic Audit</h2>
                <div className="h-1 w-20 bg-primary rounded-full"></div>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed text-xl font-medium italic">
              "{insight.aiInsight || "I am currently observing your patterns. Complete at least 5 more tasks for a deep behavioral audit."}"
            </p>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-3xl border border-white/10 space-y-4">
            <h4 className="text-xs font-black uppercase tracking-widest text-slate-400">Coach's Verdict</h4>
            <div className="space-y-3">
              <VerdictItem label="Consistency" status={completionRate > 70 ? 'Optimal' : 'Needs Work'} />
              <VerdictItem label="Focus Window" status="Morning" />
              <VerdictItem label="Recovery" status="Balanced" />
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Category Performance */}
        <div className="glass-card p-8 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-slate-900 uppercase tracking-tight">Category Mastery</h3>
            <Info size={16} className="text-slate-300" />
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={100}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {categoryData.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                  <span className="text-sm text-slate-700 font-bold">{d.name}</span>
                </div>
                <span className="text-sm font-black text-slate-900">{d.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Mistake Identification */}
        <div className="glass-card p-8 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-slate-900 uppercase tracking-tight">Mistake Identification</h3>
            <AlertTriangle size={18} className="text-danger" />
          </div>
          <div className="space-y-6">
            <MistakeItem 
              label="Delay Patterns" 
              count={stats.delayed} 
              message={stats.delayed > 3 ? "Critical delay trend detected in evening blocks." : "Minimal delays detected. Good focus."}
              severity={stats.delayed > 5 ? "high" : stats.delayed > 2 ? "medium" : "low"}
            />
            <MistakeItem 
              label="Skip Frequency" 
              count={stats.skipped} 
              message={stats.skipped > 2 ? "You tend to skip high-effort tasks like Gym." : "Excellent commitment to all categories."}
              severity={stats.skipped > 3 ? "high" : stats.skipped > 1 ? "medium" : "low"}
            />
            <div className="p-6 bg-primary/5 rounded-2xl border border-primary/10 space-y-2">
              <p className="text-sm font-bold text-primary uppercase tracking-wider">Improvement Suggestion</p>
              <p className="text-slate-600 font-medium">"Try moving your most skipped category to the first 2 hours of your day when willpower is highest."</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScoreCard({ label, score, icon, trend, description, suffix = "" }: { label: string, score: number, icon: React.ReactNode, trend: 'up' | 'down', description: string, suffix?: string }) {
  return (
    <div className="glass-card p-8 space-y-6 group hover:border-primary/30 transition-all">
      <div className="flex items-center justify-between">
        <div className="p-3 bg-slate-50 rounded-2xl group-hover:bg-primary/10 transition-colors">{icon}</div>
        <div className={`flex items-center gap-1 text-xs font-black ${trend === 'up' ? 'text-primary' : 'text-danger'}`}>
          {trend === 'up' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
          {trend === 'up' ? '+12%' : '-5%'}
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{label}</p>
        <p className="text-4xl font-black text-slate-900">{score}{suffix}</p>
        <p className="text-xs text-slate-500 font-medium leading-relaxed pt-2">{description}</p>
      </div>
    </div>
  );
}

function VerdictItem({ label, status }: { label: string, status: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-400 font-medium">{label}</span>
      <span className="font-bold text-primary">{status}</span>
    </div>
  );
}

function MistakeItem({ label, count, message, severity }: { label: string, count: number, message: string, severity: 'low' | 'medium' | 'high' }) {
  const colors = {
    low: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    medium: 'bg-amber-50 text-amber-700 border-amber-100',
    high: 'bg-red-50 text-red-700 border-red-100'
  };

  return (
    <div className={`p-6 rounded-2xl border-2 ${colors[severity]} space-y-2`}>
      <div className="flex items-center justify-between">
        <span className="font-black text-xs uppercase tracking-widest">{label}</span>
        <span className="text-2xl font-black">{count}</span>
      </div>
      <p className="text-sm font-medium opacity-90 leading-relaxed">{message}</p>
    </div>
  );
}

