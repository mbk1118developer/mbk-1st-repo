import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, TaskCategory, PlanType } from '../types';
import { Sparkles, Plus, Loader2, BrainCircuit, CalendarDays, CalendarRange, CalendarCheck, Clock, Repeat } from 'lucide-react';
import { generateSchedule } from '../services/ai';
import { motion } from 'motion/react';
import { format, addHours, startOfHour } from 'date-fns';

export default function AddTasks({ profile, onComplete }: { profile: UserProfile, onComplete: () => void }) {
  const [mode, setMode] = useState<'manual' | 'ai'>('manual');
  const [planType, setPlanType] = useState<PlanType>('Daily');
  const [taskName, setTaskName] = useState('');
  const [category, setCategory] = useState<TaskCategory>('Personal');
  const [scheduledDate, setScheduledDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [scheduledTime, setScheduledTime] = useState(format(addHours(startOfHour(new Date()), 1), 'HH:mm'));
  const [duration, setDuration] = useState('60');
  const [isRecurring, setIsRecurring] = useState(false);
  const [aiInput, setAiInput] = useState('');
  const [loading, setLoading] = useState(false);

  const categories: TaskCategory[] = ['Study', 'Gym/Fitness', 'Work', 'Sports', 'Religious', 'Personal'];

  const handleManualAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskName.trim()) return;

    setLoading(true);
    try {
      const dateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      await addDoc(collection(db, 'tasks'), {
        userId: profile.uid,
        name: taskName,
        category,
        status: 'pending',
        isAiGenerated: false,
        scheduledTime: dateTime.toISOString(),
        duration: parseInt(duration),
        isRecurring,
        createdAt: new Date().toISOString(),
        delayedCount: 0,
        planType: 'Daily'
      });
      setTaskName('');
      onComplete();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'tasks');
    } finally {
      setLoading(false);
    }
  };

  const handleAiGenerate = async () => {
    const taskList = aiInput.split('\n').filter(t => t.trim());
    if (taskList.length === 0) return;

    setLoading(true);
    try {
      const generatedTasks = await generateSchedule(taskList, profile, planType);
      
      const batch = generatedTasks.map(t => 
        addDoc(collection(db, 'tasks'), {
          ...t,
          userId: profile.uid,
          status: 'pending',
          isAiGenerated: true,
          createdAt: new Date().toISOString(),
          delayedCount: 0,
          planType
        }).catch(err => handleFirestoreError(err, OperationType.CREATE, 'tasks'))
      );

      await Promise.all(batch);
      onComplete();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-10">
      <header className="text-center space-y-4">
        <div className="inline-flex p-2 bg-primary/10 rounded-2xl text-primary mb-2">
          <Sparkles size={24} />
        </div>
        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Design Your Strategy</h1>
        <p className="text-slate-500 text-lg max-w-md mx-auto">Aura uses behavioral science to build a schedule that actually works for you.</p>
      </header>

      <div className="flex p-1.5 bg-slate-200/50 backdrop-blur-sm rounded-2xl shadow-inner">
        <button 
          onClick={() => setMode('manual')}
          className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold transition-all duration-300 ${
            mode === 'manual' ? 'bg-white text-slate-900 shadow-md scale-[1.02]' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Plus size={20} />
          Manual Entry
        </button>
        <button 
          onClick={() => setMode('ai')}
          className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold transition-all duration-300 ${
            mode === 'ai' ? 'bg-white text-slate-900 shadow-md scale-[1.02]' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <BrainCircuit size={20} className="text-secondary" />
          AI Strategy
        </button>
      </div>

      {mode === 'manual' ? (
        <motion.form 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleManualAdd} 
          className="glass-card p-10 space-y-8 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          
          <div className="space-y-3">
            <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Task Identity</label>
            <input 
              type="text" 
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              placeholder="e.g. Morning Workout, Deep Work Session..."
              className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all text-lg font-medium"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Schedule Date</label>
              <div className="relative">
                <CalendarCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="date" 
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full pl-12 pr-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all font-medium"
                  required
                />
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Start Time</label>
              <div className="relative">
                <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="time" 
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full pl-12 pr-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all font-medium"
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Duration (Minutes)</label>
              <input 
                type="number" 
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all font-medium"
                min="1"
                required
              />
            </div>
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Recurring Protocol</label>
              <button
                type="button"
                onClick={() => setIsRecurring(!isRecurring)}
                className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl border-2 transition-all font-bold ${
                  isRecurring ? 'bg-primary/10 border-primary text-primary' : 'bg-slate-50 border-slate-100 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Repeat size={20} />
                  <span>Repeat Daily</span>
                </div>
                <div className={`w-10 h-6 rounded-full relative transition-colors ${isRecurring ? 'bg-primary' : 'bg-slate-300'}`}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isRecurring ? 'left-5' : 'left-1'}`}></div>
                </div>
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Focus Category</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {categories.map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-4 py-3 rounded-xl text-sm font-bold border-2 transition-all duration-200 ${
                    category === cat 
                      ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20' 
                      : 'bg-white border-slate-100 text-slate-600 hover:border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <button 
            disabled={loading}
            className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg shadow-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 uppercase tracking-widest"
          >
            {loading ? <Loader2 className="animate-spin" /> : <Plus size={24} />}
            Confirm Mission
          </button>
        </motion.form>
      ) : (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-10 space-y-8 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>

          <div className="space-y-4">
            <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Strategy Horizon</label>
            <div className="grid grid-cols-3 gap-3">
              <PlanButton 
                active={planType === 'Daily'} 
                onClick={() => setPlanType('Daily')} 
                icon={<CalendarCheck size={18} />} 
                label="Daily" 
              />
              <PlanButton 
                active={planType === 'Weekly'} 
                onClick={() => setPlanType('Weekly')} 
                icon={<CalendarRange size={18} />} 
                label="Weekly" 
              />
              <PlanButton 
                active={planType === 'Monthly'} 
                onClick={() => setPlanType('Monthly')} 
                icon={<CalendarDays size={18} />} 
                label="Monthly" 
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black text-slate-700 uppercase tracking-widest">Task Manifest</label>
            <textarea 
              value={aiInput}
              onChange={(e) => setAiInput(e.target.value)}
              placeholder="List your goals for this period...&#10;• Gym&#10;• Study Advanced React&#10;• Evening Prayer&#10;• Read 20 pages"
              className="w-full h-56 px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-secondary/10 focus:border-secondary outline-none transition-all resize-none text-lg leading-relaxed font-medium"
            />
            <div className="flex items-start gap-2 p-3 bg-secondary/5 rounded-xl border border-secondary/10">
              <BrainCircuit className="text-secondary shrink-0 mt-0.5" size={16} />
              <p className="text-xs text-secondary font-medium">Aura will optimize durations: Study blocks will be longer, Prayer sessions will be short and frequent, and Gym will be placed in peak energy windows.</p>
            </div>
          </div>

          <button 
            onClick={handleAiGenerate}
            disabled={loading || !aiInput.trim()}
            className="w-full py-5 bg-gradient-to-r from-secondary to-primary text-white rounded-2xl font-black text-lg shadow-2xl shadow-secondary/30 hover:opacity-95 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 uppercase tracking-widest"
          >
            {loading ? <Loader2 className="animate-spin" /> : <Sparkles size={24} />}
            Generate {planType} Strategy
          </button>
        </motion.div>
      )}
    </div>
  );
}

function PlanButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all duration-300 ${
        active 
          ? 'bg-secondary text-white border-secondary shadow-lg shadow-secondary/20 scale-105' 
          : 'bg-white border-slate-100 text-slate-500 hover:border-slate-200 hover:bg-slate-50'
      }`}
    >
      {icon}
      <span className="text-xs font-black uppercase tracking-tighter">{label}</span>
    </button>
  );
}


